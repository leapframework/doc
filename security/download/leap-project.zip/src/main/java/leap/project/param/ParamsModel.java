package leap.project.param;

/**
 * Created by KAEL on 2015/11/5.
 */
public class ParamsModel {
    public String param1;
    public String param2;
    public ParamsModel pm1;
}
