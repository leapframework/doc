/**
 * 
 */
document.getElementById("head").onclick = function(){
	alert("hello leap!");
}