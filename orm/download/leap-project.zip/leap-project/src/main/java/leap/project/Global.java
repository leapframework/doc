package leap.project;

import leap.project.inteceptor.GlobalInteceptor;
import leap.web.App;
import leap.web.security.SecurityConfigurator;

public class Global extends App {
	private SecurityConfigurator sc;
	
	@Override
	protected void init() throws Throwable {
		interceptors().add(new GlobalInteceptor());
	}
}
