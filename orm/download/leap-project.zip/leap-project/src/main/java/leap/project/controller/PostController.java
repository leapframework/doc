package leap.project.controller;

import leap.core.validation.Validation;
import leap.lang.intercepting.State;
import leap.web.action.ActionContext;
import leap.web.action.ActionExecution;
import leap.web.action.ActionInterceptor;
public class PostController implements ActionInterceptor {
	public void index(){
		
	}
	@Override
	public State preExecuteAction(ActionContext context, Validation validation)
			throws Throwable {
		System.out.println("PostController.preActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public State postExecuteAction(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("PostController.postActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public void completeExecuteAction(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("PostController.completeActionExecuting");
	}
	
}

