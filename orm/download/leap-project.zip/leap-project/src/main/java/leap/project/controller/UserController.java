package leap.project.controller;

import leap.project.inteceptor.ActionInteceptor;
import leap.project.param.ParamsModel;
import leap.web.action.ControllerBase;
import leap.web.annotation.InterceptedBy;
import leap.web.annotation.Path;
import leap.web.annotation.PathVariable;
import leap.web.annotation.http.GET;
import leap.web.view.ViewData;

/**
 * Created by KAEL on 2015/11/4.
 */
@Path("/user_controller")
public class UserController extends ControllerBase {
	private byte b;
	private short s;
    @Path("user_index")
    @GET
    public String index(ViewData vd){
    	vd.put("name", "jim");
    	result().getViewData().put("age", 20);
        return "view:/user_list.html";
    }
    @Path("/user_list")
    @InterceptedBy(ActionInteceptor.class)
    public String list(int param1, Integer param10, long param2, Long param11, 
    		char param3, Character param12, 
    		float param4, Float param13, double param5, Double param14, 
    		byte param6, Byte param15, short param7, Short param16,  
    		boolean param8, Boolean param17, String param9){
    	System.out.println("int:Integer");
        System.out.println(param1);
        System.out.println(param10);
        System.out.println("long:Long");
        System.out.println(param2);
        System.out.println(param11);
        System.out.println("char:Character");
        System.out.println(param3);
        System.out.println(param12);
        System.out.println("float:Float");
        System.out.println(param4);
        System.out.println(param13);
        System.out.println("double:Double");
        System.out.println(param5);
        System.out.println(param14);
        System.out.println("byte:Byte");
        System.out.println(param6);
        System.out.println(param15);
        System.out.println("short:Short");
        System.out.println(param7);
        System.out.println(param16);
        System.out.println("boolean:Boolean");
        System.out.println(param8);
        System.out.println(param17);
        System.out.println("String");
        System.out.println(param9);
        
        System.out.println(b);
        System.out.println(s);
        return "redirect:/user_controller/user_index";
    }
    @Path("user_params/{paramName}")
    public void userParams(ParamsModel pm, @PathVariable("paramName") String paramName,ViewData vd){
    	result().getViewData();
    	System.out.println(paramName);
    	System.out.println(pm.param1);
    	System.out.println(pm.param2);
    }
}
