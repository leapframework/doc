package leap.project.inteceptor;

import leap.lang.intercepting.State;
import leap.web.Request;
import leap.web.RequestExecution;
import leap.web.RequestInterceptor;
import leap.web.Response;

public class GlobalInteceptor implements RequestInterceptor {
	@Override
	public State preHandleRequest(Request request, Response response)
			throws Throwable {
		System.out.println("GlobalInteceptor.preRequest");
		return State.CONTINUE;
	}
	
	@Override
	public State postHandleRequest(Request request, Response response,
			RequestExecution execution) throws Throwable {
		System.out.println("GlobalInteceptor.postRequest");
		return State.CONTINUE;
	}
	@Override
	public void completeHandleRequest(Request request, Response response,
			RequestExecution execution) throws Throwable {
		System.out.println("GlobalInteceptor.completeRequest");
	}
}
