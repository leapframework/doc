package leap.project.inteceptor;

import leap.core.validation.Validation;
import leap.lang.intercepting.State;
import leap.web.action.ActionContext;
import leap.web.action.ActionExecution;
import leap.web.action.ActionInterceptor;

public class ActionInteceptor implements ActionInterceptor {
	@Override
	public State preExecuteAction(ActionContext context, Validation validation)
			throws Throwable {
		System.out.println("ActionInteceptor.preActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public State postExecuteAction(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("ActionInteceptor.postActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public void completeExecuteAction(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("ActionInteceptor.completeActionExecuting");
	}
}
