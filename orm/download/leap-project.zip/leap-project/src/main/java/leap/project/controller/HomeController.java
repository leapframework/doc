package leap.project.controller;

/**
 * Created by KAEL on 2015/11/3.
 */
public class HomeController {
    public void index(){
    }
}
