package leap.project.inteceptor;

import leap.core.validation.Validation;
import leap.lang.intercepting.State;
import leap.web.action.ActionContext;
import leap.web.action.ActionExecution;
import leap.web.action.ActionInterceptorAdapter;

public class ActionInteceptor extends ActionInterceptorAdapter {
	@Override
	public State preActionExecuting(ActionContext context, Validation validation)
			throws Throwable {
		System.out.println("ActionInteceptor.preActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public State postActionExecuting(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("ActionInteceptor.postActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public void completeActionExecuting(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("ActionInteceptor.completeActionExecuting");
	}
}
