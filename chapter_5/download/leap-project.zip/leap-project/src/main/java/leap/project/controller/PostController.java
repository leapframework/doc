package leap.project.controller;

import leap.core.validation.Validation;
import leap.lang.intercepting.State;
import leap.web.action.ActionContext;
import leap.web.action.ActionExecution;
import leap.web.action.ActionInterceptorAdapter;
public class PostController extends ActionInterceptorAdapter {
	public void index(){
		
	}
	@Override
	public State preActionExecuting(ActionContext context, Validation validation)
			throws Throwable {
		System.out.println("PostController.preActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public State postActionExecuting(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("PostController.postActionExecuting");
		return State.CONTINUE;
	}
	
	@Override
	public void completeActionExecuting(ActionContext context,
			Validation validation, ActionExecution execution) throws Throwable {
		System.out.println("PostController.completeActionExecuting");
	}
	
}

